<?php defined('BASEPATH') or exit('No direct script acces allowed');
class kategori_model extends CI_Model
{
    protected $_tabel = 'kategori';
    protected $primary = 'id';

    public function getAll()
    {
        return $this->db->get($this->_tabel)->result();
    }
}
